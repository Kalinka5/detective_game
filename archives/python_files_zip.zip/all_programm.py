story = {
    1: {
        "en": {
            "text": "\nYou chose a story difficulty level.",
            "voice": {
                '1': "vvauthor_say2.wav"
            }
        },
        "укр": {
            "text": "\nВи обрали легкий рівень складності.",
            "voice": {
                '1': "vrecord_ua2.wav"
            }
        },
        "time": 3,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 4
        },
    },

    2: {
        "en": {
            "text": "\nYou chose the hard difficulty level.",
            "voice": {
                '1': "vvauthor_say47.wav"
            }
        },
        "укр": {
            "text": "\nВи обрали важкий рівень складності.",
            "voice": {
                '1': "vrecord_ua127.wav"
            }
        },
        "time": 3,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 3
        },
    },

    3: {
        "en": {
            "text": '\nAt the beginning you have 10 lives.'
                    '\nIn this story you will play short games. '
                    '\nAnd if you do not complete the task, then every time a life is taken away. '
                    '\nPoints are also deducted for incorrect answers.'
                    '\nWhen life ends, you will automatically lose.',
            "voice": {
                '1': "vvauthor_say48.wav"
            }
        },
        "укр": {
            "text": '\nНа початку у вас є 10 життів.'
                    '\nУ цій історії ви будете грати в короткі ігри.'
                    '\nІ за кожну поразку будуть забирати життя.'
                    '\nЗа неправильні відповіді також забирають життя.'
                    '\nКоли закінчується життя – ви автоматично програєте.',
            "voice": {
                '1': "vrecord_ua128.wav"
            }
        },
        "time": 17,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 4
        },
    },

    4: {
        "en": {
            "text": "\nLet me tell you one story in which you will take part.",
            "voice": {
                '1': "vvauthor_say3.wav"
            }
        },
        "укр": {
            "text": "\nРозповім вам одну історію, в якій ви приймете участь.",
            "voice": {
                '1': "vrecord_ua3.wav"
            }
        },
        "time": 4,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 5
        },
    },

    5: {
        "en": {
            "text": '\nOne day suddenly a security guard found a dead body on the stairs of the City Center Mall. '
                    '\nThe security guard was horrified when he saw that. Frightened, he immediately called the police. '
                    '\nHe was very scared and could not even speak properly in the call. He said to the police, "Hello, come here quickly. '
                    '\nSomebody’s dead body is here. A corpse is in front of me." '
                    '\nSaying this, he immediately disconnected the phone and sat in a chair nearby.',
            "voice": {
                '1': "vvauthor_say4.wav"
            }
        },
        "укр": {
            "text": '\nОдного разу охоронець раптово виявив на сходах ТРЦ мертве тіло.'
                    '\nПобачивши це, охоронець жахнувся. Він одразу викликав поліцію.'
                    '\nВін був дуже наляканий і навіть не міг нормально говорити під час дзвінка. '
                    '\nВін сказав поліцейським: «Здрастуйте, швидше сюди. Тут чиєсь мертве тіло. Переді мною труп».'
                    '\nСказавши це, він негайно відключив телефон і сів у крісло поруч.',
            "voice": {
                '1': "vrecord_ua4.wav"
            }
        },
        "time": 26,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 6
        },
    },

    6: {
        "en": {
            "text": "\nBut detective Dan Kaliny arrived faster...",
            "voice": {
                '1': "vvauthor_say5.wav"
            }
        },
        "укр": {
            "text": "\nАле детектив Ден Каліні прибув швидше...",
            "voice": {
                '1': "vrecord_ua5.wav"
            }
        },
        "time": 3,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 7
        },
    },

    7: {
        "en": {
            "text": '\n"Wow, what a wonderful day it is.'
                    '\nI get up early this morning, had breakfast with a fresh croissant with poppy seed cream filling.'
                    '\nThen I immediately go to the gym "Kalinka". It was the best training I have ever made. '
                    '\nAfter training, I wanted to meet with my friend Mike, I haven`t seen him for a long time. '
                    '\nI have to meet him at one o\'clock. Ohh, I`m late..."',
            "voice": {
                '1': "vvdan_say1.wav"
            }
        },
        "укр": {
            "text": '\n«Вау, який чудовий день.'
                    '\nСьогодні вранці я встав раніше ніж завжди, поснідав свіжим круасаном з вершково-маковою начинкою.'
                    '\nТоді відразу пішов до спортзалу «Калинка». Це було найкраще тренування, яке я коли-небудь проводив.'
                    '\nПісля тренування я хотів зустрітися зі своїм другом Майком, я його давно не бачив.'
                    '\nЯ маю зустрітися з ним о першій годині. Ой, я спізнююсь...".',
            "voice": {
                '1': "vrecord_ua6.wav"
            }
        },
        "time": 26,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 8
        },
    },

    8: {
        "en": {
            "text": "\nYou walked into the mall...",
            "voice": {
                '1': "vvauthor_say6.wav"
            }
        },
        "укр": {
            "text": "\nВи зайшли в торговельний центр...",
            "voice": {
                '1': "vrecord_ua7.wav"
            }
        },
        "time": 2,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 9
        },
    },

    9: {
        "en": {
            "text": '\nYou thought, "What a change this mall has made, and just a month ago, it almost burned down".',
            "voice": {
                '1': "vvdan_say2.wav"
            }
        },
        "укр": {
            "text": "\nВи подумали: «Які зміни зробив цей торговий центр, а всього місяць тому він ледь не згорів повністю».",
            "voice": {
                '1': "vrecord_ua8.wav"
            }
        },
        "time": 6,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 10
        },
    },

    10: {
        "en": {
            "text": "And then you saw a crowd of people standing on the stairs and looking at something.",
            "voice": {
                '1': "vvauthor_say7.wav"
            }
        },
        "укр": {
            "text": "Зненацька ви побачили натовп людей, які стояли на сходах і на щось дивилися.",
            "voice": {
                '1': "vrecord_ua9.wav"
            }
        },
        "time": 6,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 11
        },

    },

    11: {
        "en": {
            "text": "\nWhat will you do first? (go to the toilet(1), call to friend to know where is he(2), approach the crowd(3))",
            "voice": {
                '1': "vvauthor_say8.wav"
            }
        },
        "укр": {
            "text": "\nЩо ви зробите спочатку? (піти до туалету(1), подзвонити другу, щоб дізнатися, де він(2), підійти до натовпу(3))",
            "voice": {
                '1': "vrecord_ua10.wav"
            }
        },
        "time": 5,
        "interactive": {
            "type": "choice",
            "level": "easy",
            "next": {
                "1": 12,
                "2": 15,
                "3": 18
            }
        },

    },

    12: {
        "en": {
            "text": "\nYou went to the toilet...",
            "voice": {
                '1': "vvauthor_say9.wav"
            }
        },
        "укр": {
            "text": "\nВи пішли в туалет.",
            "voice": {
                '1': "vrecord_ua11.wav"
            }
        },
        "time": 2,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 13
        },
    },

    13: {
        "en": {
            "text": '\n"Ohh, this is what I’ve been waiting for..."'
                    '\nOhh    ahhhh     mmm     well done!',
            "voice": {
                '1': "vvdan_say3.wav",
            }
        },
        "укр": {
            "text": '\n"Ох, це те, на що я чекав ще зранку..."'
                    '\nОуу    уфффф     ммм     чудово!',
            "voice": {
                '1': "vrecord_ua12.wav"
            }
        },
        "time": 5,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 14
        },
    },

    14: {
        "en": {
            "text": '\nAfter you peed a little, you saw that the police had arrived and you won`t be able to examine the corpse.\n'
                    '\nGAME OVER!',
            "voice": {
                '1': "vvauthor_say10.wav",
            }
        },
        "укр": {
            "text": '\nПісля того, як ви трохи помочилися, ви побачили, що приїхала поліція і ви не зможете оглянути труп.'
                    '\nКінець гри!',
            "voice": {
                '1': "vrecord_ua13.wav"
            }
        },
        "time": 8,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 0
        },
    },

    15: {
        "en": {
            "text": '\nYou start calling to Mike.',
            "voice": {
                '1': "vvauthor_say11.wav"
            }
        },
        "укр": {
            "text": '\nВи починаєте телефонувати Майку.',
            "voice": {
                '1': "vrecord_ua14.wav"
            }
        },
        "time": 3,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 16
        },
    },

    16: {
        "en": {
            "text": 'RING...      RING...      RING...        RING...',
            "voice": {
                '1': "vvauthor_say12.wav"
            }
        },
        "укр": {
            "text": 'RING...      RING...      RING...        RING...',
            "voice": {
                '1': "vrecord_ua129.wav"
            }
        },
        "time": 4,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 17
        },
    },

    17: {
        "en": {
            "text": '\n"Strange, maybe he can\'t hear? Perhaps he is among that crowd, and there he definitely won’t hear the call."',
            "voice": {
                '1': "vvdan_say4.wav"
            }
        },
        "укр": {
            "text": '\n«Дивно, може, він не чує? Може, він серед того натовпу, а там точно не почує дзвінка».',
            "voice": {
                '1': "vrecord_ua15.wav"
            }
        },
        "time": 8,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 18
        },
    },

    18: {
        "en": {
            "text": '\nYou approached the crowd and saw the corpse.\nThere were shouts from the crowd:',
            "voice": {
                '1': "vvauthor_say13.wav",
            }
        },
        "укр": {
            "text": '\nВи підійшли до натовпу і побачили труп.\nБуло чутно вигуки з натовпу:',
            "voice": {
                '1': "vrecord_ua16.wav"
            }
        },
        "time": 5,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 19
        },
    },

    19: {
        "en": {
            "text": '- Ohh, It can`t be.\n- I don`t believe it!',
            "voice": {
                '1': "vvcry_say1.wav"
            }
        },
        "укр": {
            "text": '- Ой, не може бути.\n- Я не вірю!',
            "voice": {
                '1': "vrecord_ua17.wav"
            }
        },
        "time": 7,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 20
        },
    },

    20: {
        "en": {
            "text": '\nYou start to investigate body. An ID card was found on the man’s shirt with his name written on it. '
                    '\nHis name was "Mike Williams", an employee of a company.',
            "voice": {
                '1': "vvauthor_say14.wav"
            }
        },
        "укр": {
            "text": '\nВи починаєте досліджувати тіло. На сорочці чоловіка знайшли посвідчення особи з його іменем.'
                    '\nЙого звали «Майк Вільямс», він був співробітником компанії.',
            "voice": {
                '1': "vrecord_ua18.wav"
            }
        },
        "time": 10,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 21
        },
    },

    21: {
        "en": {
            "text": '\n"It`s Mike, my old friend... It`s impossible!"',
            "voice": {
                '1': "vvdan_say5.wav"
            }
        },
        "укр": {
            "text": '\n«Це Майк, мій старий друг... Це неможливо!»',
            "voice": {
                '1': "vrecord_ua19.wav"
            }
        },
        "time": 4,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 22
        },
    },

    22: {
        "en": {
            "text": '\nYou saw fire scars on the arms.\n"Hmm, I guess he\'s a bad cook" - you thought.',
            "voice": {
                '1': "vvauthor_say15.wav",
                '2': "vvdan_say6.wav"
            }
        },
        "укр": {
            "text": '\nВи побачили вогняні шрами на руках. «Хм, він завжди погано готував...» - подумали ви.',
            "voice": {
                '1': "vrecord_ua20.wav",
                '2': "vrecord_ua21.wav"
            }
        },
        "time": 8,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 23
        },
    },

    23: {
        "en": {
            "text": '\nAfter examining the body, you realized that there were non-bullet and no stab wounds.'
                    '\n"So he was poisoned..."',
            "voice": {
                '1': 'vvauthor_say16.wav',
                '2': 'vvdan_say7.wav'
            }
        },
        "укр": {
            "text": '\nОглянувши тіло, ви зрозуміли, що кульових і ножових поранень немає.'
                    '\n"Отже, його отруїли..."',
            "voice": {
                '1': "vrecord_ua22.wav",
                '2': "vrecord_ua23.wav"
            }
        },
        "time": 8,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 24
        },
    },

    24: {
        "en": {
            "text": '\nNow you had to know who killed Mike and who left him here?',
            "voice": {
                '1': "vvauthor_say17.wav"
            }
        },
        "укр": {
            "text": '\nТепер ви повинні знайти, хто вбив Майка і хто залишив його тут?',
            "voice": {
                '1': "vrecord_ua24.wav"
            }
        },
        "time": 7,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 25
        },
    },

    25: {
        "en": {
            "text": '\n"I`m sure it`s not an accident, he was killed by someone..."',
            "voice": {
                '1': "vvdan_say8.wav"
            }
        },
        "укр": {
            "text": '\n«Я впевнений, що це не випадковість, його хтось вбив...»',
            "voice": {
                '1': "vrecord_ua25.wav"
            }
        },
        "time": 5,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 26
        },
    },

    26: {
        "en": {
            "text": '\nAfter knowing all this, you made the decision.'
                    '\nYou went to Mike’s house...',
            "voice": {
                '1': "vvauthor_say18.wav",
            }
        },
        "укр": {
            "text": '\nДізнавшись усе це, ви прийняли рішення.'
                    '\nВи пішли до будинку Майка...',
            "voice": {
                '1': "vrecord_ua26.wav"
            }
        },
        "time": 6,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 27
        },
    },

    27: {
        "en": {
            "text": '\nOn there way home, you told the sad news to his family. They were deeply saddened to hear of Mike`s death.',
            "voice": {
                '1': "vvauthor_say19.wav"
            }
        },
        "укр": {
            "text": '\nКоли приїхали до його будинку ви повідомили сумну новину родині.'
                    '\nСім\'я була глибоко засмучена, дізнавшись про смерть Майка.',
            "voice": {
                '1': "vrecord_ua27.wav"
            }
        },
        "time": 9,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 28
        },
    },

    28: {
        "en": {
            "text": '\n"I need to ask his family if they know something..."'
                    '\nYou:       Have you seen how Mike burn his hands?',
            "voice": {
                '1': "vvdan_say9.wav",
            }
        },
        "укр": {
            "text": '\n«Мені потрібно запитати його родину, чи вони щось знають...»'
                    '\nТи:        Ви бачили, як Майк обпалив свої руки?',
            "voice": {
                '1': "vrecord_ua28.wav"
            }
        },
        "time": 9,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 29
        },
    },

    29: {
        "en": {
            "text": '\nSuddenly the wife took you to the kitchen, locked the door and she said:',
            "voice": {
                '1': "vvauthor_say20.wav"
            }
        },
        "укр": {
            "text": '\nРаптом дружина Майка повела вас на кухню, замкнула двері і сказала:',
            "voice": {
                '1': "vrecord_ua29.wav"
            }
        },
        "time": 7,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 30
        },
    },

    30: {
        "en": {
            "text": '\nJessica:   A month and a half ago, Mike came home from work and told me:'
                    '\n           "In 2 weeks we will be rich, pay off all our debts, move to the New Orleans and start a new life."'
                    '\n           Then I ask: "What`s happening?"',
            "voice": {
                '1': "vvjessica_say1.wav",
                '2': "vvmike_say1.wav",
                '3': "vvjessica_say2.wav"
            }
        },
        "укр": {
            "text": '\nДжессіка:  Півтора місяція тому Майк прийшов додому з роботи і сказав мені:'
                    '\n           «Через 2 тижні ми розбагатіємо, розплатимося з боргами, переїдемо в Новий Орлеан і почнемо нове життя».'
                    '\n           Тоді я спитала: «Що відбувається?».',
            "voice": {
                '1': "vrecord_ua30.wav",
                '2': "vrecord_ua31.wav",
                '3': "vrecord_ua32.wav",
                '4': "vrecord_ua33.wav"
            }
        },
        "time": 14,
        "interactive": {
            "type": "common",
            "level": "hard1",
            "next": 31
        },
    },

    31: {
        "en": {
            "text": '\nJessica:   He said, "Please don`t ask me nothing, just wait. '
                    '\n           And one more request, do not come to the mall on June 7, I will be very busy."'
                    '\n           I told, "Okay". But my thoughts were lousy.',
            "voice": {
                '1': "vvjessica_say3.wav",
                '2': "vvmike_say2.wav",
                '3': "vvjessica_say4.wav"
            }
        },
        "укр": {
            "text": '\nДжессіка:  Він сказав: «Будь ласка, не питай мене ні про що, просто почекай.'
                    '\n           І ще одне прохання, не приходьте в торговий центр 7 червня, я буду дуже зайнятий».'
                    '\n           Я сказала: "Добре". Але мої думки були кепські.',
            "voice": {
                '1': "vrecord_ua34.wav",
                '2': "vrecord_ua35.wav",
            }
        },
        "time": 14,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 32
        },
    },

    32: {
        "en": {
            "text": '\nYou:       And the fire was happened on the 7th...',
            "voice": {
                '1': "vvdan_say10.wav"
            }
        },
        "укр": {
            "text": '\nТи:        Пожежа також сталася 7-го...',
            "voice": {
                '1': "vrecord_ua36.wav"
            }
        },
        "time": 4,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 33
        },
    },

    33: {
        "en": {
            "text": '\nJessica:   Yes, - she answered excitedly. '
                    '\n           That evening I saw in news that City Center Mall was burning, '
                    '\n           at once I start ringing to Mike`s phone, but he didn\'t answer the phone... '
                    '\n           That night he came home. He had blisters on his hands, they were burned.'
                    '\n           He said, by reason of the fire he burned his arms. To this day, we have treated his hands.',
            "voice": {
                '1': "vvjessica_say5.wav",
            }
        },
        "укр": {
            "text": '\nДжессіка:  Так, - схвильовано відповіла вона.'
                    '\n           Того вечора я побачила у новинах, що горить ТРЦ,'
                    '\n           я відразу почала дзвонити на телефон Майка, але він не відповідав...'
                    '\n           Тієї ночі він прийшов додому. На долонях у нього були пухирі, його руки були обпалені повністю.'
                    '\n           За його словами, внаслідок пожежі він обпік їх. До цього дня ми лікували його руки...',
            "voice": {
                '1': "vrecord_ua37.wav"
            }
        },
        "time": 23,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 34
        },
    },

    34: {
        "en": {
            "text": '\nYou:       Hmm, Ok... Today we have... July 10th and during this time you have not moved to New Orleans yet?',
            "voice": {
                '1': "vvdan_say11.wav"
            }
        },
        "укр": {
            "text": '\nТи:        Хм, добре... Сьогодні у нас... 10 липня, і за цей час ви ще не переїхали до Нового Орлеана?',
            "voice": {
                '1': "vrecord_ua38.wav"
            }
        },
        "time": 8,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 35
        },
    },

    35: {
        "en": {
            "text": '\nJessica:   After the fire he`s not himself. He was in conflict with his superiors every day.',
            "voice": {
                '1': "vvjessica_say6.wav"
            }
        },
        "укр": {
            "text": '\nДжессіка:  Після пожежі він сам не свій. Щодня конфліктував із начальством.',
            "voice": {
                '1': "vrecord_ua39.wav"
            }
        },
        "time": 6,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 36
        },
    },

    36: {
        "en": {
            "text": '\nYou:       And he told you something about it?'
                    '\n\nJessica:   Nope.'
                    '\n\nYou:       Hmm, thank you, miss, for your cooperation.',
            "voice": {
                '1': "vvdan_say12.wav",
                '2': "vvjessica_say7.wav",
                '3': "vvdan_say13.wav"
            }
        },
        "укр": {
            "text": '\nТи:        І він вам казав через що це?'
                    '\n\nДжессіка:  Ні.'
                    '\n\nТи:        Хм, дякую, міс, за співпрацю.',
            "voice": {
                '1': "vrecord_ua40.wav"
            }
        },
        "time": 8,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 37
        },
    },

    37: {
        "en": {
            "text": '\nAfter inquiring thoroughly, you thought of going to Mike`s office.'
                    '\nYou came to the mall again...',
            "voice": {
                '1': "vvauthor_say21.wav",
            }
        },
        "укр": {
            "text": '\nРетельно розпитавши, ви вирішили піти до офісу Майка.'
                    '\nВи знову прийшли в торговельний центр...',
            "voice": {
                '1': "vrecord_ua41.wav"
            }
        },
        "time": 6,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 38
        },
    },

    38: {
        "en": {
            "text": '\nYou:       Jeez! How many police officers here.',
            "voice": {
                '1': "vvdan_say14.wav"
            }
        },
        "укр": {
            "text": '\nТи:        Господи! Скільки тут поліцейських.',
            "voice": {
                '1': "vrecord_ua42.wav"
            }
        },
        "time": 4,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 39
        },
    },

    39: {
        "en": {
            "text": '\nIn the corner you saw an old friend. In childhood, you were all friends, Mike, Mary and you.',
            "voice": {
                '1': "vvauthor_say22.wav"
            }
        },
        "укр": {
            "text": '\nУ кутку ви побачили стару подружку. У дитинстві ви всі разом грали Майк, Мері та ти.',
            "voice": {
                '1': "vrecord_ua43.wav"
            }
        },
        "time": 8,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 40
        },
    },

    40: {
        "en": {
            "text": "You decided to go to Mary...",
            "voice": {
                '1': "vvauthor_say23.wav"
            }
        },
        "укр": {
            "text": "Ви вирішили піти до Мері...",
            "voice": {
                '1': "vrecord_ua44.wav"
            }
        },
        "time": 2,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 41
        },
    },

    41: {
        "en": {
            "text": '\n"She looked terrible. She cried non-stop. I\'m embarrassed." - you thought.'
                    '\nYou:       Hi, Mary, my regrets. I still can\'t believe it myself.'
                    '\n\nMary:      Wow, Dan, like I haven\'t seen you for ages. ',
            "voice": {
                '1': "vvdan_say15.wav",
                '3': "vvmary_say1.wav"
            }
        },
        "укр": {
            "text": '\n«Вона виглядає жахливо. Плаче без упину. Мені аж ніяково.» - подумали ви.'
                    '\nТи:        Привіт, Мері, мої співчуття. Я досі не можу в це повірити.'
                    '\n\nМери:      Ох, Ден, наче я не бачила тебе цілу вічність. ',
            "voice": {
                '1': "vrecord_ua45.wav"
            }
        },
        "time": 15,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 42
        },
    },

    42: {
        "en": {
            "text": '\nShe hugged you. And cried even more on your chest.'
                    '\n"Hmm, she was excessively in love with him in childhood, and maybe now..."',
            "voice": {
                '1': "vvauthor_say24.wav",
                '2': "vvdan_say16.wav"
            }
        },
        "укр": {
            "text": '\nВона вас обійняла. І ще дужче заплакала на ваших грудях.'
                    '\n«Хм, вона в дитинстві була в нього надмірно закохана, а може і зараз...»',
            "voice": {
                '1': "vrecord_ua46.wav",
                '2': "vrecord_ua47.wav"
            }
        },
        "time": 12,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 43
        },
    },

    43: {
        "en": {
            "text": '\nMary:      What are you doing here, Dan?',
            "voice": {
                '1': "vvmary_say2.wav"
            }
        },
        "укр": {
            "text": '\nМери:      Що ти тут робиш, Ден?',
            "voice": {
                '1': "vrecord_ua48.wav"
            }
        },
        "time": 4,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 44
        },
    },

    44: {
        "en": {
            "text": '\nYou:       I was supposed to meet Mike here...',
            "voice": {
                '1': "vvdan_say17.wav"
            }
        },
        "укр": {
            "text": '\nТи:        Я мав зустрітися з Майком в цьому місці...',
            "voice": {
                '1': "vrecord_ua49.wav"
            }
        },
        "time": 4,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 45
        },
    },

    45: {
        "en": {
            "text": '\nYou saw the recorder in her hand.',
            "voice": {
                '1': "vvauthor_say25.wav"
            }
        },
        "укр": {
            "text": '\nВи побачили диктофон у її руці.',
            "voice": {
                '1': "vrecord_ua50.wav"
            }
        },
        "time": 3,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 46
        },
    },

    46: {
        "en": {
            "text": '\nYou:       Are you recording someone? "I know that she`s a journalist."',
            "voice": {
                '1': "vvdan_say18.wav"
            }
        },
        "укр": {
            "text": '\nТи:        Ти когось записуєшь? «Я знаю, що вона журналістка.»',
            "voice": {
                '1': "vrecord_ua51.wav"
            }
        },
        "time": 7,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 47
        },
    },

    47: {
        "en": {
            "text": '\nShe was confused.',
            "voice": {
                '1': "vvauthor_say26.wav"
            }
        },
        "укр": {
            "text": '\nВона розгубилась.',
            "voice": {
                '1': "vrecord_ua52.wav"
            }
        },
        "time": 2,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 48
        },
    },

    48: {
        "en": {
            "text": '\nMary:      Oh, It was Mike`s recorder. He left it to me and said that he would pick it up at one o\'clock...',
            "voice": {
                '1': "vvmary_say3.wav"
            }
        },
        "укр": {
            "text": '\nМери:      О, це був диктофон Майка. Він залишив його мені і сказав, що забере о першій годині...',
            "voice": {
                '1': "vrecord_ua53.wav"
            }
        },
        "time": 10,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 49
        },
    },

    49: {
        "en": {
            "text": '\nYou thought, "There is something important and I need to get it".',
            "voice": {
                '1': "vvdan_say19.wav"
            }
        },
        "укр": {
            "text": '\nВам спало на думку: «У ньому є щось важливе, і мені потрібно це отримати...»',
            "voice": {
                '1': "vrecord_ua54.wav"
            }
        },
        "time": 7,
        "interactive": {
            "type": "common",
            "level": "hard2",
            "next": 50
        },
    },

    50: {
        "en": {
            "text": '\nYou suggested to move her to an uninhabited place.',
            "voice": {
                '1': "vvauthor_say27.wav"
            }
        },
        "укр": {
            "text": '\nВи запропонували перейти їй в безлюдне місце.',
            "voice": {
                '1': "vrecord_ua55.wav"
            }
        },
        "time": 5,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 51
        },
    },

    51: {
        "en": {
            "text": '\nYou:       Mary, you understand that Mike did not just leave the recorder for you, it contains a certain secret.'
                    '\n           And since he`s already been killed, it`s time to take advantage of it.',
            "voice": {
                '1': "vvdan_say20.wav"
            }
        },
        "укр": {
            "text": '\nТи:        Мері, ти розумієш, що Майк не просто так залишив тобі диктофон, у ньому є певна таємниця.'
                    '\n           І оскільки його вже вбили, настав час скористатися ним.',
            "voice": {
                '1': "vrecord_ua56.wav"
            }
        },
        "time": 12,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 52
        },
    },

    52: {
        "en": {
            "text": '\nMary:      Hmm... She looked around, making sure no one was around. And turned on the recorder.',
            "voice": {
                '1': "vvmary_say4.wav",
                '2': "vvauthor_say28.wav"
            }
        },
        "укр": {
            "text": '\nМери:      Хм... «Вона озирнулася, переконавшись, що поруч нікого немає. І увімкнула диктофон».',
            "voice": {
                '1': "vrecord_ua57.wav",
                '2': "vrecord_ua58.wav"
            }
        },
        "time": 7,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 53
        },
    },

    53: {
        "en": {
            "text": '\n"After recording... Everything cleared up."'
                    '\n"The mall owner killed Mike."',
            "voice": {
                '1': "vvdan_say21.wav"
            }
        },
        "укр": {
            "text": '\n«Після запису... Все прояснилося.»'
                    '\n«Власник торгового центру вбив Майка.»',
            "voice": {
                '1': "vrecord_ua59.wav"
            }
        },
        "time": 6,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 54
        },
    },

    54: {
        "en": {
            "text": '\nYou:       Mary, please approach the police in 15 minutes and tell them '
                    '\n           that the owner knows some information about the victim. In the meantime, I`ll go to Mr. Brown.',
            "voice": {
                '1': "vvdan_say22.wav"
            }
        },
        "укр": {
            "text": '\nТи:        Мері, будь ласка, підійди до поліції за 15 хвилин і скажи їм, '
                    '\n           що власнику відома якась інформація про потерпілого. Тим часом я піду до містера Брауна.',
            "voice": {
                '1': "vrecord_ua60.wav"
            }
        },
        "time": 12,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 55
        },
    },

    55: {
        "en": {
            "text": '\nMary:      Good luck.',
            "voice": {
                '1': "vvmary_say5.wav"
            }
        },
        "укр": {
            "text": '\nМери:      Удачі.',
            "voice": {
                '1': "vrecord_ua61.wav"
            }
        },
        "time": 2,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 56
        },
    },

    56: {
        "en": {
            "text": '\nYou took the elevator up to the 19th floor. '
                    '\nWhen you arrived you saw a long corridor in front of the owner`s office, where a security guard was sitting.',
            "voice": {
                '1': "vvauthor_say29.wav"
            }
        },
        "укр": {
            "text": '\nВи викликали ліфт на 19 поверх.'
                    '\nКоли ви приїхали, ви побачили довгий коридор перед офісом власника, де сидів охоронець.',
            "voice": {
                '1': "vrecord_ua62.wav"
            }
        },
        "time": 11,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 57
        },
    },

    57: {
        "en": {
            "text": '\nHe asked: - Who are you?',
            "voice": {
                '1': "vvauthor_say30.wav",
                '2': "vvsec_say1.wav"
            }
        },
        "укр": {
            "text": '\nВін запитав: - Ви хто?',
            "voice": {
                '1': "vrecord_ua63.wav",
                '2': "vrecord_ua64.wav"
            }
        },
        "time": 3,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 58
        },
    },

    58: {
        "en": {
            "text": '\nWhat do you say? ("I`m a police officer"(1), "I`m detective"(2)) ',
            "voice": {
                '1': "vvauthor_say31.wav"
            }
        },
        "укр": {
            "text": '\nЩо ви скажете? («Я з поліції»(1), «Я детектив»(2)) ',
            "voice": {
                '1': "vrecord_ua65.wav"
            }
        },
        "time": 4,
        "interactive": {
            "type": "choice",
            "level": "easy",
            "next": {
                '1': 59,
                '2': 63
            }
        },
    },

    59: {
        "en": {
            "text": '\nYou:       I`m a police officer.',
            "voice": {
                '1': "vvdan_say23.wav"
            }
        },
        "укр": {
            "text": '\nТи:        Я з поліції.',
            "voice": {
                '1': "vrecord_ua66.wav"
            }
        },
        "time": 3,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 60
        },
    },

    60: {
        "en": {
            "text": '\nSecurity:  Ohh, Yes, what do you need? - the guard asked.',
            "voice": {
                '1': "vvsec_say2.wav"
            }
        },
        "укр": {
            "text": '\nОхоронець: Оу, так? І що вам треба? - питає охоронець.',
            "voice": {
                '1': "vrecord_ua67.wav"
            }
        },
        "time": 6,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 61
        },
    },

    61: {
        "en": {
            "text": '\nYou:       Can I approached to the owner`s cabinet?',
            "voice": {
                '1': "vvdan_say24.wav"
            }
        },
        "укр": {
            "text": '\nТи:        Чи можу я зайти до кабінету власника ТРЦ?',
            "voice": {
                '1': "vrecord_ua68.wav"
            }
        },
        "time": 5,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 62
        },
    },

    62: {
        "en": {
            "text": '\nHe called on the phone and after a few sentences, he hung up. He said:'
                    '\nSecurity:  Please pass.',
            "voice": {
                '1': "vvauthor_say32.wav",
                '2': "vvsec_say3.wav"
            }
        },
        "укр": {
            "text": '\nВін подзвонив по телефону і через декілька секунд поклав трубку. Він сказав:'
                    '\nОхоронець: Будь ласка проходьте.',
            "voice": {
                '1': "vrecord_ua69.wav",
                '2': "vrecord_ua70.wav"
            }
        },
        "time": 11,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 70
        },
    },

    63: {
        "en": {
            "text": '\nYou:       I`m detective.'
                    '\n\nSecurity:  Hmm, You have the wrong floor sir.',
            "voice": {
                '1': "vvdan_say25.wav",
                '2': "vvsec_say4.wav"
            }
        },
        "укр": {
            "text": '\nТи:        Я детектив.'
                    '\n\nОхоронець: Хмм, сер, ви помилилися поверхом.',
            "voice": {
                '1': "vrecord_ua71.wav"
            }
        },
        "time": 3,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 64
        },
    },

    64: {
        "en": {
            "text": '\nYou:       No, friend, it`s you who made a mistake.',
            "voice": {
                '1': "vvdan_say26.wav"
            }
        },
        "укр": {
            "text": '\nТи:        Ні, друже, це ти зробив помилку.',
            "voice": {
                '1': "vrecord_ua72.wav"
            }
        },
        "time": 5,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 65
        },
    },

    65: {
        "en": {
            "text": '\nSecurity:  Hey Bobby, I found entertainment for us...'
                    '\n\nComes out a big bearded man...',
            "voice": {
                '1': "vvsec_say5.wav",
                '2': "vvauthor_say33.wav"
            }
        },
        "укр": {
            "text": '\nОхоронець: Гей, Боббі, я знайшов для нас розвагу...'
                    '\n\nВиходить великий бородатий здоровань...',
            "voice": {
                '1': "vrecord_ua73.wav"
            }
        },
        "time": 9,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 66
        },
    },

    66: {
        "en": {
            "text": '\nBobby:     I LOVE FUN, AHAHAHA.',
            "voice": {
                '1': "vvsec2_say1.wav"
            }
        },
        "укр": {
            "text": '\nБоббі:     Я ЛЮБЛЮ РОЗВАГИ, ХА-ХА-ХА.',
            "voice": {
                '1': "vrecord_ua74.wav"
            }
        },
        "time": 4,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 67
        },
    },

    67: {
        "en": {
            "text": '\nYou just thought: "Ohh shit".',
            "voice": {
                '1': "vvdan_say27.wav"
            }
        },
        "укр": {
            "text": '\nВи одразу подумали: "От, дідько".',
            "voice": {
                '1': "vrecord_ua75.wav"
            }
        },
        "time": 4,
        "interactive": {
            "type": "common",
            "level": "hard3",
            "next": 68
        },
    },

    68: {
        "en": {
            "text": '\nBAAANG        BOOOM       BAAAM       DOOOM.',
            "voice": {
                '1': "vvauthor_say34.wav"
            }
        },
        "укр": {
            "text": '\nБАААХ       БУУУМ        ШААААХ       БЕЕЕМ.',
            "voice": {
                '1': "vrecord_ua76.wav"
            }
        },
        "time": 4,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 69
        },
    },

    69: {
        "en": {
            "text": '\nYou:      It wasn\'t too easy...',
            "voice": {
                '1': "vvdan_say28.wav"
            }
        },
        "укр": {
            "text": '\nТи:        Оу, це було не надто легко...',
            "voice": {
                '1': "vrecord_ua77.wav"
            }
        },
        "time": 3,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 70
        },
    },

    70: {
        "en": {
            "text": '\nYou enter to the owner`s cabinet...',
            "voice": {
                '1': "vvauthor_say35.wav"
            }
        },
        "укр": {
            "text": '\nВи входите до кабінету власника...',
            "voice": {
                '1': "vrecord_ua78.wav"
            }
        },
        "time": 3,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 71
        },
    },

    71: {
        "en": {
            "text": '\nYou saw Mr. Brown. '
                    '\nHe was a big, beefy man with hardly any neck, although he did have a very large mustache. '
                    '\nHis face was almost completely hidden by a long, shaggy mane of hair and a wild, tangled beard, '
                    '\nbut you could make out his eyes, glinting like black beetles under all the hair.',
            "voice": {
                '1': "vvauthor_say36.wav"
            }
        },
        "укр": {
            "text": '\nВи бачите містера Брауна.'
                    '\nЦе був великий, кремезний чоловік без шиї, хоча в нього були дуже великі вуса. '
                    '\nЙого обличчя було майже повністю приховано довгою кудлатою гривою волосся та дикою скуйовдженою бородою, '
                    '\nале можна було розрізнити його очі, що блищали під усім волоссям, як чорні жуки.',
            "voice": {
                '1': "vrecord_ua79.wav"
            }
        },
        "time": 23,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 72
        },
    },

    72: {
        "en": {
            "text": '\nYou:       Hello, Mr. Brown.',
            "voice": {
                '1': "vvdan_say29.wav"
            }
        },
        "укр": {
            "text": '\nТи:        Доброго дня, містере Браун.',
            "voice": {
                '1': "vrecord_ua80.wav"
            }
        },
        "time": 3,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 73
        },
    },

    73: {
        "en": {
            "text": '\nMr. Brown: Hello, mister...'
                    '\n\nYou:       Kaliny...',
            "voice": {
                '1': "vvmr_brown_say1.wav",
                '2': "vvdan_say30.wav"
            }
        },
        "укр": {
            "text": '\nБраун:     Доброго, містере...'
                    '\n\nТи:        Каліні...',
            "voice": {
                '1': "vrecord_ua81.wav"
            }
        },
        "time": 4,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 74
        },
    },

    74: {
        "en": {
            "text": '\nYou:       I have a few questions for you. I know that you killed Mike Williams. '
                    '\n           I give you a chance to tell everything yourself.',
            "voice": {
                '1': "vvdan_say31.wav"
            }
        },
        "укр": {
            "text": '\nТи:        У мене до вас декілька запитань. Я знаю, що саме ви вбили Майка Вільямса.'
                    '\n           Я даю вам можливість самому все розповісти.',
            "voice": {
                '1': "vrecord_ua82.wav"
            }
        },
        "time": 11,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 75
        },
    },

    75: {
        "en": {
            "text": '\nMr. Brown: Are you kidding me? This is some sort of a gamble. I didn\'t kill him.',
            "voice": {
                '1': "vvmr_brown_say2.wav"
            }
        },
        "укр": {
            "text": '\nБраун:     Ви жартуєте? Це якась гра? Я його не вбивав.',
            "voice": {
                '1': "vrecord_ua83.wav"
            }
        },
        "time": 6,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 76
        },
    },

    76: {
        "en": {
            "text": '\nYou:       Let me refresh your memory.',
            "voice": {
                '1': "vvdan_say32.wav"
            }
        },
        "укр": {
            "text": '\nТи:        Дозвольте освіжити вашу пам\'ять.',
            "voice": {
                '1': "vrecord_ua84.wav"
            }
        },
        "time": 5,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 77
        },
    },

    77: {
        "en": {
            "text": '\nWho set fire to the mall? ',
            "voice": {
                '1': "vvauthor_say37.wav"
            }
        },
        "укр": {
            "text": '\nХто підпалив торговельний центр? ',
            "voice": {
                '1': "vrecord_ua85.wav"
            }
        },
        "time": 1,
        "interactive": {
            "type": "question1",
            "level": "easy",
            "next": 78
        },
    },

    78: {
        "en": {
            "text": '\nYou:       It was YOU who convinced Mike to set fire to the mall. '
                    '\n           You insured the mall before you burned it down. '
                    '\n           But you wanted to play it safe and agreed with Mike to set fire to the building. '
                    '\n           You promised him 20 percent of the amount.',
            "voice": {
                '1': "vvdan_say33.wav"
            }
        },
        "укр": {
            "text": '\nТи:        Це ви підмовили Майка підпалити торговий центр.'
                    '\n           Ви застрахували торговий центр перед тим, як спалити його.'
                    '\n           Але ви хотіли перестрахуватися і домовилися з Майком підпалити будівлю.'
                    '\n           Ви обіцяли йому 20 відсотків від суми.',
            "voice": {
                '1': "vrecord_ua87.wav"
            }
        },
        "time": 18,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 79
        },
    },

    79: {
        "en": {
            "text": '\nMr. Brown sighed nervously.',
            "voice": {
                '1': "vvauthor_say39.wav"
            }
        },
        "укр": {
            "text": '\n«Містер Браун нервово зітхнув.»',
            "voice": {
                '1': "vrecord_ua88.wav"
            }
        },
        "time": 3,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 80
        },
    },

    80: {
        "en": {
            "text": '\nWhat body part did Mike burn? ',
            "voice": {
                '1': "vvauthor_say40.wav"
            }
        },
        "укр": {
            "text": '\nЯка частина тіла Майка згоріла? ',
            "voice": {
                '1': "vrecord_ua89.wav"
            }
        },
        "time": 2,
        "interactive": {
            "type": "question2",
            "level": "easy",
            "next": 81
        },
    },

    81: {
        "en": {
            "text": '\nYou:       When Mike set fire to the center, he burned his hands. '
                    '\n           It`s strange, because all your personnel were evacuated and not a single one was injured.',
            "voice": {
                '1': "vvdan_say34.wav"
            }
        },
        "укр": {
            "text": '\nТи:        Коли Майк підпалив центр, він обпік собі руки.'
                    '\n           Це дивно, тому що весь ваш персонал був евакуйований і ніхто не постраждав.',
            "voice": {
                '1': "vrecord_ua90.wav"
            }
        },
        "time": 11,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 82
        },
    },

    82: {
        "en": {
            "text": '\nMr. Brown: Keep going.',
            "voice": {
                '1': "vvmr_brown_say3.wav"
            }
        },
        "укр": {
            "text": '\nБраун:     Продовжуйте.',
            "voice": {
                '1': "vrecord_ua91.wav"
            }
        },
        "time": 2,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 83
        },
    },

    83: {
        "en": {
            "text": '\nWhat June did the fire happen? (number) ',
            "voice": {
                '1': "vvauthor_say41.wav"
            }
        },
        "укр": {
            "text": '\nЯкого червня сталася пожежа? (число) ',
            "voice": {
                '1': "vrecord_ua92.wav"
            }
        },
        "time": 2,
        "interactive": {
            "type": "question3",
            "level": "easy",
            "next": 84
        },
    },

    84: {
        "en": {
            "text": '\nYou:       After June 7, when the fire broke out, you did not give the promised money to Mike '
                    '\n           for a whole month. Then he began to blackmail you by recording your conversation. '
                    '\n           You wanted to get a voice recorder. And then...',
            "voice": {
                '1': "vvdan_say35.wav"
            }
        },
        "укр": {
            "text": '\nТи:        Після 7 червня, коли сталася пожежа, ви не віддавали Майку обіцяні гроші цілий місяць.'
                    '\n           Потім він почав вас шантажувати, записаною вашою розмовою під час договору.'
                    '\n           Ви хотіли отримати диктофон. І потім...',
            "voice": {
                '1': "vrecord_ua93.wav"
            }
        },
        "time": 17,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 85
        },
    },

    85: {
        "en": {
            "text": '\nHow was Mike killed? (shot, stabbed or poisoned) ',
            "voice": {
                '1': "vvauthor_say42.wav"
            }
        },
        "укр": {
            "text": '\nЯк вбили Майка? (застрелили, зарізали чи отруїли) ',
            "voice": {
                '1': "vrecord_ua94.wav"
            }
        },
        "time": 2,
        "interactive": {
            "type": "question4",
            "level": "easy",
            "next": 86
        },
    },

    86: {
        "en": {
            "text": '\nYou:       You met with him on the pretext that you would hand over the money. '
                    '\n           But in the end you poisoned him! But Mike expected it. '
                    '\n           He left the dictaphone to the journalist. '
                    '\n           You will go to jail for 15 years, do you understand that?',
            "voice": {
                '1': "vvdan_say36.wav"
            }
        },
        "укр": {
            "text": '\nТи:        Ви зустрілися з ним під приводом, що віддасте гроші. '
                    '\n           Але зрештою ви його отруїли! Але Майк це очікував. Він залишив журналістці свій диктофон.'
                    '\n           Ти сядеш у в\'язницю на 15 років щонайменше.',
            "voice": {
                '1': "vrecord_ua95.wav"
            }
        },
        "time": 17,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 87
        },
    },

    87: {
        "en": {
            "text": '\nMr. Brown: I still have time to run Mr. Kaliny. Security!',
            "voice": {
                '1': "vvmr_brown_say4.wav"
            }
        },
        "укр": {
            "text": '\nБраун:     Я ще маю час втекти містере Каліні. Охорона!',
            "voice": {
                '1': "vrecord_ua96.wav"
            }
        },
        "time": 5,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 88
        },
    },

    88: {
        "en": {
            "text": '\nYou:       It won\'t help. Cause the police will come in 3...',
            "voice": {
                '1': "vvdan_say37.wav"
            }
        },
        "укр": {
            "text": '\nТи:        Це не допоможе. Тому що поліція прийде через 3...',
            "voice": {
                '1': "vrecord_ua97.wav"
            }
        },
        "time": 6,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 89
        },
    },

    89: {
        "en": {
            "text": '\n           2',
            "voice": {
                '1': "vvdan_say38.wav"
            }
        },
        "укр": {
            "text": '\n           2',
            "voice": {
                '1': "vrecord_ua98.wav"
            }
        },
        "time": 2,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 90
        },
    },

    90: {
        "en": {
            "text": '\n           1',
            "voice": {
                '1': "vvdan_say39.wav"
            }
        },
        "укр": {
            "text": '\n           1',
            "voice": {
                '1': "vrecord_ua99.wav"
            }
        },
        "time": 2,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 91
        },
    },

    91: {
        "en": {
            "text": '\n"Knock-Knock-Knock".',
            "voice": {
                '1': "vvauthor_say43.wav"
            }
        },
        "укр": {
            "text": '\n"Тук-Тук-Тук".',
            "voice": {
                '1': "vrecord_ua100.wav"
            }
        },
        "time": 2,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 92
        },
    },

    92: {
        "en": {
            "text": '\nThe police come in...'
                    '\nMr. Brown looks frightened, he abruptly opens the window and jumps out of it.',
            "voice": {
                '1': "vvauthor_say44.wav",
            }
        },
        "укр": {
            "text": '\nЗаходить поліція...'
                    '\nМістер Браун виглядає дуже переляканим, він різко відкриває вікно і вистрибує з нього.',
            "voice": {
                '1': "vrecord_ua101.wav"
            }
        },
        "time": 7,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 93
        },
    },

    93: {
        "en": {
            "text": '\n"And he jumped from a height of a 19-storey building, by the way" - you was thinking.',
            "voice": {
                '1': "vvdan_say40.wav"
            }
        },
        "укр": {
            "text": '\n«А він, до речі, стрибнув з висоти 19-поверхового будинку.» — подумали ви.',
            "voice": {
                '1': "vrecord_ua102.wav"
            }
        },
        "time": 7,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 94
        },
    },

    94: {
        "en": {
            "text": '\nOne of the cops asks:\n- What`s happening?',
            "voice": {
                '1': "vvauthor_say45.wav"
            }
        },
        "укр": {
            "text": '\nОдин із копів запитує:\n- Що відбувається?',
            "voice": {
                '1': "vrecord_ua103.wav"
            }
        },
        "time": 5,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 95
        },
    },

    95: {
        "en": {
            "text": '\n- He said, "His last desire was to fly". He made it... - you said.',
            "voice": {
                '1': "vvdan_say41.wav"
            }
        },
        "укр": {
            "text": '\n– Він сказав: «Його останнім бажанням було літати». Він зробив це... - сказали ви.',
            "voice": {
                '1': "vrecord_ua104.wav"
            }
        },
        "time": 7,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 96
        },
    },

    96: {
        "en": {
            "text": '\nConclusion.'
                    '\nThe owner of the shopping center, Mr. Brown, crashed from a bird\'s eye view. '
                    '\nMiss Mary published an article about the whole situation and became '
                    '\nthe most in-demand journalist in the USA. '
                    '\nWell, our detective Dan Kaliny will be back with a new investigation. See you soon.',
            "voice": {
                '1': "vvauthor_say46.wav"
            }
        },
        "укр": {
            "text": '\nЗавершення.'
                    '\nВласник торгового центру містер Браун розбився з висоти пташиного польоту.'
                    '\nМіс Мері опублікувала статтю про всю цю ситуацію і стала'
                    '\nнайбільш затребуваною журналісткою у США. '
                    '\nЩо ж до нашого детектива, Ден Каліні, він ще повернеться з новим розслідуванням. До зустрічі.',
            "voice": {
                '1': "vrecord_ua105.wav"
            }
        },
        "time": 20,
        "interactive": {
            "type": "common",
            "level": "easy",
            "next": 0
        },
    },









}
